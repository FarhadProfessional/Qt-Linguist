# graph-centrality

implementation of paper ["A Family of Centrality Measures for Graph Data Based on Subgraphs"](https://drops.dagstuhl.de/opus/volltexte/2020/11947/pdf/LIPIcs-ICDT-2020-23.pdf)!
